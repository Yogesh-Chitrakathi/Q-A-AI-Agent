import os
from llama_index import GPTVectorStoreIndex, download_loader
from dotenv import load_dotenv
import openai

# Load environment variables
load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
GOOGLE_API_CREDENTIALS_PATH = os.getenv("GOOGLE_API_CREDENTIALS_PATH")

openai.api_key = OPENAI_API_KEY

# 1. Load Google Docs using LlamaIndex's GoogleDocsReader
def load_google_docs():
    GoogleDocsReader = download_loader("GoogleDocsReader")
    loader = GoogleDocsReader(credentials_path=GOOGLE_API_CREDENTIALS_PATH)
    # You can specify document IDs or load all accessible docs
    docs = loader.load_data()
    return docs

# 2. Build the index
def build_index(docs):
    index = GPTVectorStoreIndex.from_documents(docs)
    return index

# 3. Q&A function using OpenAI
def ask_question(index, question):
    query_engine = index.as_query_engine()
    response = query_engine.query(question)
    return response.response

def main():
    print("Loading Google Docs...")
    docs = load_google_docs()
    print(f"Loaded {len(docs)} documents.")

    print("Building index...")
    index = build_index(docs)
    print("Index built.")

    # Simple CLI for testing
    while True:
        question = input("\nAsk a question (or type 'exit'): ")
        if question.lower() == "exit":
            break
        answer = ask_question(index, question)
        print(f"Answer: {answer}")

if __name__ == "__main__":
    main() 